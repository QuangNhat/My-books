#ifndef __COMMON_H__
#define __COMMON_H__

#include <Windows.h>							// Header File For Windows
#include <math.h>								// Header File For Windows Math Library
#include <stdio.h>								// Header File For Standard Input/Output
#include "GL.h"									// Header File For The OpenGL32 Library
#include "GLU.h"								// Header File For The GLu32 Library
#include "Constants.h"							// Header File For Constants
#include "SOIL.h"								// Header File For Simple OpenGL Image Library

#include <stdarg.h>								// Header File For Variable Argument Routines

#endif