﻿#ifndef __CONSTANTS_H__
#define __CONSTANTS_H__

namespace Bilbo
{

	/*
	* Class Name
	*/
#define CLASS_NAME		"OpenGL"

	/*
	* Parameters For Perspective
	*/
#define VIEW_ANGLE		45.0f								// Viewing Angle Of The Perspective
#define Z_NEAR			0.1f								// The Start Point Of The Perspective
#define Z_FAR			100.0f								// The End Point Of The Perspective
#define ASPECT_RATIO(width, height) ((GLfloat)width / (GLfloat)height)	// The Aspect Ratio Of The Window

	/*
	* Resolutions Of Screen
	*/
	// 16:9
#define RESOLUTION_1360X768_W			1360
#define RESOLUTION_1360X768_H			768
	// 5:4
#define RESOLUTION_1280X1024_W			1280
#define RESOLUTION_1280X1024_H			1024
	// 4:3
#define RESOLUTION_1280X960_W			1280
#define RESOLUTION_1280X960_H			960
	// 16:10
#define RESOLUTION_1280X800_W			1280
#define RESOLUTION_1280X800_H			800
	// 5:3
#define RESOLUTION_1280X768_W			1280
#define RESOLUTION_1280X768_H			768
	// 16:9
#define RESOLUTION_1280X720_W			1280
#define RESOLUTION_1280X720_H			720
	// 4:3
#define RESOLUTION_1152X864_W			1152
#define RESOLUTION_1152X864_H			864
	// 4:3
#define RESOLUTION_1024X768_W			1024
#define RESOLUTION_1024X768_H			768
	// 4:3
#define RESOLUTION_800X600_W			800
#define RESOLUTION_800X600_H			600
	// 4:3
#define RESOLUTION_640X480_W			640
#define RESOLUTION_640X480_H			480

	/*
	* Window Title
	*/
#define TITLE_WINDOW_ERROR						"Error"
#define TITLE_WINDOW_SHUTDOWN_ERROR				"Shutdown Error"
#define TITLE_WINDOW_MODE						"Window Mode"
#define TITLE_WINDOW_APPLICATION				"Bilbo Framework"

	/*
	* Messages
	*/
#define MESSAGE_ERROR_RELEASE_DC_RC				"Release Of DC And RC Failed."
#define MESSAGE_ERROR_RELEASE_DC				"Release Device Context Failed."
#define MESSAGE_ERROR_RELEASE_RC				"Release Rendering Context Failed."
#define MESSAGE_ERROR_RELEASE_HWND				"Could Not Release hWnd."
#define MESSAGE_ERROR_UNREGISTER_CLASS			"Could Not Unregister Class."
#define MESSAGE_ERROR_REGISTER_CLASS			"Failed To Register The Window Class."
#define MESSAGE_ERROR_FULLSCREEN				"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Window Mode Instead?"
#define MESSAGE_ERROR_CREATE_WND				"Window Creation Error."
#define MESSAGE_ERROR_CREATE_DC					"Can't Create A GL Device Context."
#define MESSAGE_ERROR_CREATE_RC					"Can't Create A GL Rendering Context"
#define MESSAGE_ERROR_ACTIVE_RC					"Can't Active The GL Rendering Context"
#define MESSAGE_ERROR_INIT_GL					"Initialization Failed"
#define MESSAGE_ERROR_CHOOSE_PFD				"Can't Find A Suitable PixelFormat"
#define MESSAGE_ERROR_SET_PFD					"Can't Set The PixelFormat"

#define MESSAGE_WINDOW_MODE						"Would You Like To Run In Fullscreen Mode?"
#define MESSAGE_APPLICATION_QUIT				"The Program Will Now Close."

	/*
	* Color RGB
	*/

	// Black
#define COLOR_BLACK_R		0.0f
#define COLOR_BLACK_G		0.0f
#define COLOR_BLACK_B		0.0f

	// Navy
#define COLOR_NAVY_R		0.0f
#define COLOR_NAVY_G		0.0f
#define COLOR_NAVY_B		0.5f

	// Blue
#define COLOR_BLUE_R		0.0f
#define COLOR_BLUE_G		0.0f
#define COLOR_BLUE_B 		1.0f

	// Green
#define COLOR_GREEN_R 		0.0f
#define COLOR_GREEN_G 		0.5f
#define COLOR_GREEN_B 		0.0f

	// Teal
#define COLOR_TEAL_R 		0.0f
#define COLOR_TEAL_G 		0.5f
#define COLOR_TEAL_B 		0.5f

	// Lime
#define COLOR_LIME_R 		0.0f
#define COLOR_LIME_G 		1.0f
#define COLOR_LIME_B 		0.0f

	// Aqua
#define COLOR_AQUA_R 		0.0f
#define COLOR_AQUA_G 		1.0f
#define COLOR_AQUA_B 		1.0f

	// Maroon
#define COLOR_MAROON_R 		0.5f
#define COLOR_MAROON_G 		0.0f
#define COLOR_MAROON_B 		0.0f

	// Purple
#define COLOR_PURPLE_R 		0.5f
#define COLOR_PURPLE_G 		0.0f
#define COLOR_PURPLE_B 		0.5f

	// Olive
#define COLOR_OLIVE_R 		0.5f
#define COLOR_OLIVE_G 		0.5f
#define COLOR_OLIVE_B 		0.0f

	// Gray
#define COLOR_GRAY_R 		0.5f
#define COLOR_GRAY_G 		0.5f
#define COLOR_GRAY_B 		0.5f

	// Silver
#define COLOR_SILVER_R 		0.75f
#define COLOR_SILVER_G 		0.75f
#define COLOR_SILVER_B 		0.75f

	// Red
#define COLOR_RED_R 		1.0f
#define COLOR_RED_G 		0.0f
#define COLOR_RED_B 		0.0f

	// Fuchsia
#define COLOR_FUCHSIA_R 	1.0f
#define COLOR_FUCHSIA_G 	0.0f
#define COLOR_FUCHSIA_B 	1.0f

	// Yellow
#define COLOR_YELLOW_R 		1.0f
#define COLOR_YELLOW_G 		1.0f
#define COLOR_YELLOW_B 		0.0f

	// White
#define COLOR_WHITE_R 		1.0f
#define COLOR_WHITE_G 		1.0f
#define COLOR_WHITE_B 		1.0f

}


#endif