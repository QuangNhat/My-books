#ifndef __COMMON_H__
#define __COMMON_H__

#include <Windows.h>							// Header File For Windows
#include <math.h>								// Header File For Windows Math Library
#include <stdio.h>								// Header File For Standard Input/Output
#include <GL\GL.h>								// Header File For The OpenGL32 Library
#include <GL\GLU.h>								// Header File For The GLu32 Library
#include "Constants.h"							// Header File For Constants
#include "include\GL\SOIL.h"							// Header File For Simple OpenGL Image Library

#include <stdarg.h>			// Header File For Variable Argument Routines

#endif